'use client'

import styles from './DestinationDetailsPage.module.css'
import React, { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import dynamic from 'next/dynamic'
import type { ComponentType } from 'react'
import { AddLocationAltTwoTone } from '@mui/icons-material'

const Slider = dynamic(
  () => import('react-slick').then(mod => mod.default),
  { ssr: false }
) as ComponentType<any>

const API_BASE_URL = 'https://backend-82om.onrender.com'

interface ItineraryImage {
  id: number
  image: string
  alt_text: string
  is_primary: boolean
}

interface Itinerary {
  id: number
  dayNum: string
  name: string
  city: string
  description: string
  images: ItineraryImage[]
}

interface Destination {
  id: number
  title: string
  country: string
  all_images: string[]
  terms_and_conditions: string
  documents_required: string
}

export default function DestinationDetailsPage() {
  const { id } = useParams<{ id: string }>()

  const [destination, setDestination] = useState<Destination | null>(null)
  const [itineraries, setItineraries] = useState<Itinerary[]>([])
  const [activeTab, setActiveTab] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!id) return

    const loadData = async () => {
      try {
        const [destRes, itinRes] = await Promise.all([
          fetch(`${API_BASE_URL}/api/holidaypackages/${id}/`),
          fetch(
            `${API_BASE_URL}/api/holidaypackages/itineraries/?holidaypackage=${id}`
          )
        ])

        if (!destRes.ok) throw new Error('Destination fetch failed')

        const destData = await destRes.json()
        const itinData = await itinRes.json()

        setDestination(destData)
        setItineraries(itinData.results || [])
      } catch (err) {
        console.error(err)
        setError('Failed to load destination')
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [id])

  if (loading) return <div className="p-10 text-center">Loading…</div>
  if (error) return <div className="p-10 text-red-600">{error}</div>
  if (!destination) return null

  const tabs = [
    {
      label: 'Itinerary',
      content: (
        <div className={styles.itineraryContainer}>
          {itineraries.map(itinerary => (
            <div key={itinerary.id} className={styles.itineraryCard}>
              <h3>{itinerary.dayNum} – {itinerary.name}</h3>
              <p className={styles.city}>
                <AddLocationAltTwoTone /> {itinerary.city}
              </p>

              {itinerary.images?.[0] && (
                <img
                  src={itinerary.images[0].image}
                  alt={itinerary.images[0].alt_text}
                  className={styles.itineraryImage}
                />
              )}

              <div
                dangerouslySetInnerHTML={{ __html: itinerary.description }}
              />
            </div>
          ))}
        </div>
      )
    },
    {
      label: 'Terms & Conditions',
      content: (
        <div
          dangerouslySetInnerHTML={{
            __html: destination.terms_and_conditions
          }}
        />
      )
    },
    {
      label: 'Summary',
      content: <p>{destination.documents_required}</p>
    }
  ]

  return (
    <div className={styles.destinationContainer}>
      <img
        src={`${API_BASE_URL}${destination.all_images?.[0]}`}
        alt={destination.title}
        className="w-full h-[450px] object-cover rounded-lg"
      />

      <div className="p-8">
        <h1 className="text-3xl font-bold">{destination.title}</h1>
        <p className="text-gray-500 mb-6">{destination.country}</p>

        <div className={styles.tabsHeader}>
          {tabs.map((tab, i) => (
            <button
              key={i}
              onClick={() => setActiveTab(i)}
              className={activeTab === i ? styles.active : ''}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className={styles.tabContent}>
          {tabs[activeTab].content}
        </div>
      </div>
    </div>
  )
}
